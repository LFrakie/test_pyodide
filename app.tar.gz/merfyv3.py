import requests
from bs4 import BeautifulSoup
import flet as ft

def main(page):
    page.title = 'Merfy-v3'
    url_toscrap = ft.TextField(value='https://mercafy.blogspot.com/search?q=store', label="Url", autofocus=True)
    # last_name = ft.TextField(label="Last name")
    resultscrap = ft.Column()   

    def scrapArticles(url):
        result = ""

        try:
            response = requests.get(url)
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, "html.parser")
                articles = soup.find_all("article")

                if articles:
                    for article in articles:
                        header = article.find("header")
                        a_tag = header.find("a")
                        article_url = a_tag.get("href")

                        h3_tag = article.find("h3")
                        if h3_tag:
                            title = h3_tag.text.strip()

                        p_tag = article.find("p")
                        if p_tag:
                            content = p_tag.text.strip()

                        img_tags = article.find_all("img")
                        img_urls = [img_tag.get("src") for img_tag in img_tags if img_tag.get("src")]

                        result += "Artículo encontrado:\n"
                        result += f"URL: {article_url}\n"
                        result += f"Título: {title}\n"
                        result += f"Contenido: {content}\n"
                        result += f"Img-Urls: {', '.join(img_urls)}\n\n"

                    return result
                else:
                    return "No se encontraron artículos en la página."

            else:
                return "Error: No se pudo acceder a la página (código de estado: {})".format(response.status_code)

        except Exception as e:
            return "Error: {}".format(str(e))


    def btn_click(e):
        
        url = url_toscrap.value
        articles = scrapArticles(url)
        # print(title)
        
        resultscrap.controls.append(ft.Text(f"{articles}"))

        page.update()

    page.add(
        url_toscrap,
        ft.ElevatedButton("Scrap!", on_click=btn_click),
        resultscrap,
    )

ft.app(target=main)